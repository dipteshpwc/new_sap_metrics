import React, { useState } from 'react'
import { Link } from "react-router-dom";
import './Trends.css';
import { trendsData } from '../../Data/Data';
import Box from '../Box/Box';

const Trends = () => {

    // State for Dropdown
    const [isOpen, setIsOpen] = useState(false);
    const [selectedOption, setSelectedOption] = useState(null);
    
    // State for Date Range Picker
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    // State for Minimization
    const [isMinimized, setIsMinimized] = useState(false);
  
    const dropdownOptions = ['Option 1', 'Option 2', 'Option 3'];
  
    // Dropdown Handlers
    const toggleDropdown = () => setIsOpen(!isOpen);
  
    const handleOptionClick = (option) => {
      setSelectedOption(option);
      setIsOpen(false);
    };
  
    // Date Range Handlers
    const handleStartDateChange = (e) => {
      setStartDate(e.target.value);
    };
  
    const handleEndDateChange = (e) => {
      setEndDate(e.target.value);
    };

    // Toggle Minimization
    const toggleMinimization = () => {
      setIsMinimized(!isMinimized);
    };

  return (
    <>
    <div>
      <h1>Trend Page</h1>
      <h4>Version 1.0.0</h4>     
      {/* <Link to="/">Go Back</Link>  */}
      {trendsData.map((card, id)=> {
        return(
            <div className="parentContainer">
                <Box title={card.title} color={card.color} barValue={card.barValue} value={card.value} png={card.png} series={card.series} />
            </div>
        )
      })}
    </div>

    {/* New content for the right section */}
    <div className="right-content">
        <h2>Related Filters</h2>
        <div className={`combined-component ${isMinimized ? 'minimized' : ''}`}>
          {isMinimized ? (<button className="floating-button" onClick={toggleMinimization}>&#x25B2;</button>
          ) : (
          <>
            <button className="minimize-button" onClick={toggleMinimization}>
              &#x25BC;
            </button>
            {/* Dropdown Component */}
            <div className="dropdown">
              <button className="dropdown-button" onClick={toggleDropdown}>
                {selectedOption ? selectedOption : 'Select an option'}
                <span className={`arrow ${isOpen ? 'open' : ''}`}>&#9662;</span>
              </button>
              {isOpen && (
                <ul className="dropdown-menu">
                  {dropdownOptions.map((option, index) => (
                    <li key={index} className="dropdown-item" onClick={() => handleOptionClick(option)}>
                      {option}
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* Date Range Picker Component */}
            <div className="date-range-picker">
              <input 
                type="date" 
                className="date-input" 
                value={startDate} 
                onChange={handleStartDateChange} 
              />
              <span className="date-separator">to</span>
              <input 
                type="date" 
                className="date-input" 
                value={endDate} 
                onChange={handleEndDateChange} 
              />
            </div>
          </>
          )}
        </div>
    </div>

    </>
    
  );
};

export default Trends;
