import React from 'react'

const DropdownAndDateRangePicker = () => {
  return (
    <div>
      <h1>test</h1>
    </div>
  )
}

export default DropdownAndDateRangePicker
